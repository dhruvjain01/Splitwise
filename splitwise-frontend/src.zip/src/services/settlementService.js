import { axiosPrivate } from "../api/axios";

const unwrap = (res) => res.data?.data ?? res.data;

export const settlementService = {
  // ✅ update this endpoint if your backend path differs
  getSettlement: async (groupId) => {
    const res = await axiosPrivate.get(`/api/groups/${groupId}/settle`);
    return unwrap(res);
  },
};
