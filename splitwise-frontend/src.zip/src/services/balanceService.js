import { axiosPrivate } from "../api/axios";

const unwrap = (res) => res.data?.data ?? res.data;

export const balanceService = {
  // returns list of { fromUserId, toUserId, amount }
  getBalances: async (groupId) => {
    const res = await axiosPrivate.get(`/api/groups/${groupId}/balances`);
    return unwrap(res);
  },

  // if you have a settlement endpoint (optional use later)
  getSettlement: async (groupId) => {
    const res = await axiosPrivate.get(`/api/groups/${groupId}/settlements`);
    return unwrap(res);
  },
};
