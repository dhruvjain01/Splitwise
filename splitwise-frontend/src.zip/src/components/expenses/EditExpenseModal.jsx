import { useEffect, useMemo, useState } from "react";
import Modal from "../common/Modal";
import Input from "../common/Input";
import Button from "../common/Button";

const SPLIT_TYPES = ["EQUAL", "EXACT", "PERCENTAGE"];

export default function EditExpenseModal({ open, onClose, members, expense, onUpdate }) {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");

  const [paidByUserId, setPaidByUserId] = useState("");
  const [splitType, setSplitType] = useState("EQUAL");

  // userId -> string input
  const [splitDetails, setSplitDetails] = useState({});

  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const memberOptions = useMemo(() => {
    return (members || []).map((m) => ({
      id: m.id || m.userId,
      name: m.name || m.email,
      email: m.email,
    }));
  }, [members]);

  useEffect(() => {
    if (!open || !expense) return;

    setErr("");

    setDescription(expense.description || "");
    setAmount(String(expense.amount ?? ""));

    // backend returns paidByUserId? (your response has paidByUserId)
    setPaidByUserId(expense.paidByUserId || expense.paidBy || "");

    const st = expense.splitType || "EQUAL";
    setSplitType(st);

    // init splitDetails for all members as blank
    const init = {};
    memberOptions.forEach((m) => (init[m.id] = ""));

    // ✅ splitDetails can be object OR JSON string depending on backend serialization
    let details = expense.splitDetails;

    if (typeof details === "string") {
      try {
        details = JSON.parse(details);
      } catch (e) {
        details = null;
      }
    }

    // fill from backend splitDetails first
    if (details && typeof details === "object") {
      Object.entries(details).forEach(([userId, val]) => {
        init[userId] = String(val);
      });
    }

    // ✅ IMPORTANT FIX:
    // If splitType is PERCENTAGE but backend stored splitDetails as AMOUNTS,
    // convert amounts -> percentages for prefilling UI.
    const totalAmt = Number(expense.amount || 0);
    if (st === "PERCENTAGE" && totalAmt > 0) {
      Object.keys(init).forEach((userId) => {
        const amountVal = Number(init[userId] || 0);
        if (amountVal > 0) {
          const pct = (amountVal / totalAmt) * 100;
          init[userId] = pct.toFixed(2); // show 2 decimals
        } else {
          init[userId] = "";
        }
      });
    }

    setSplitDetails(init);
  }, [open, expense, memberOptions]);

  const setSplitValue = (userId, value) => {
    setSplitDetails((prev) => ({ ...prev, [userId]: value }));
  };

  const deriveParticipantUserIds = () => {
    // Equal: include all members
    if (splitType === "EQUAL") return memberOptions.map((m) => m.id);

    // Exact/Percentage: include only those with > 0
    return memberOptions
      .map((m) => m.id)
      .filter((id) => Number(splitDetails[id] || 0) > 0);
  };

  const validate = () => {
    const amt = Number(amount);

    if (!description.trim()) return "Description is required";
    if (!amt || amt <= 0) return "Amount must be greater than 0";
    if (!paidByUserId) return "Paid by is required";
    if (memberOptions.length === 0) return "No group members found";

    const participants = deriveParticipantUserIds();

    if (splitType === "EQUAL") {
      if (!participants || participants.length === 0) return "No members available to split";
    }

    if (splitType === "EXACT") {
      if (participants.length === 0) return "Enter exact amount > 0 for at least one member";

      let sum = 0;
      for (const id of participants) {
        const v = Number(splitDetails[id] || 0);
        if (v < 0) return "Exact values must be >= 0";
        sum += v;
      }
      if (Math.abs(sum - amt) > 0.01) {
        return `Exact split must total ${amt}. Current total is ${sum.toFixed(2)}.`;
      }
    }

    if (splitType === "PERCENTAGE") {
      if (participants.length === 0) return "Enter percentage > 0 for at least one member";

      let sum = 0;
      for (const id of participants) {
        const v = Number(splitDetails[id] || 0);
        if (v < 0) return "Percent values must be >= 0";
        sum += v;
      }

      // ✅ tolerance increased because we use toFixed(2) and backend rounding
      if (Math.abs(sum - 100) > 0.1) {
        return `Percentage split must total 100%. Current total is ${sum.toFixed(2)}%.`;
      }
    }

    return null;
  };

  const buildPayload = () => {
    const amt = Number(amount);
    const participantUserIds = deriveParticipantUserIds();

    let splitDetailsPayload = null;

    if (splitType === "EXACT" || splitType === "PERCENTAGE") {
      splitDetailsPayload = {};
      participantUserIds.forEach((id) => {
        splitDetailsPayload[id] = Number(splitDetails[id] || 0);
      });
    }

    return {
      description: description.trim(),
      paidByUserId,
      amount: amt,
      participantUserIds,
      splitType,
      splitDetails: splitDetailsPayload,
    };
  };

  const submit = async (e) => {
    e.preventDefault();
    setErr("");

    const error = validate();
    if (error) {
      setErr(error);
      return;
    }

    try {
      setLoading(true);
      const payload = buildPayload();
      await onUpdate(payload);
      onClose();
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to update expense");
    } finally {
      setLoading(false);
    }
  };

  // UI totals
  const amt = Number(amount || 0);

  const exactTotal = memberOptions.reduce((acc, m) => {
    return acc + (Number(splitDetails[m.id] || 0) || 0);
  }, 0);

  const percentTotal = memberOptions.reduce((acc, m) => {
    return acc + (Number(splitDetails[m.id] || 0) || 0);
  }, 0);

  return (
    <Modal open={open} title="Edit Expense" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        {err ? <p className="text-sm text-red-600">{err}</p> : null}

        <Input
          label="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <Input
          label="Amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />

        {/* Paid by */}
        <div className="flex flex-col gap-1">
          <label className="text-sm text-gray-600">Paid by</label>
          <select
            value={paidByUserId}
            onChange={(e) => setPaidByUserId(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-black"
          >
            {memberOptions.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} ({m.email})
              </option>
            ))}
          </select>
        </div>

        {/* Split Type */}
        <div className="flex flex-col gap-1">
          <label className="text-sm text-gray-600">Split type</label>
          <select
            value={splitType}
            onChange={(e) => setSplitType(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-black"
          >
            {SPLIT_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {splitType === "EQUAL" ? (
          <div className="rounded-xl border bg-gray-50 p-3 text-sm text-gray-600">
            Equal split will include all members automatically.
          </div>
        ) : null}

        {splitType === "EXACT" ? (
          <div className="space-y-2">
            <div className="text-sm text-gray-700 font-medium">
              Enter exact amounts (leave blank or 0 to exclude)
            </div>

            <div className="space-y-2">
              {memberOptions.map((m) => (
                <div key={m.id} className="flex items-center justify-between gap-3">
                  <div className="text-sm">
                    {m.name} <span className="text-gray-500">({m.email})</span>
                  </div>
                  <input
                    type="number"
                    value={splitDetails[m.id] ?? ""}
                    onChange={(e) => setSplitValue(m.id, e.target.value)}
                    className="w-32 rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-black"
                    placeholder="0"
                  />
                </div>
              ))}
            </div>

            <div className="text-xs text-gray-500">
              Total: {exactTotal.toFixed(2)} / {amt.toFixed(2)}
            </div>
          </div>
        ) : null}

        {splitType === "PERCENTAGE" ? (
          <div className="space-y-2">
            <div className="text-sm text-gray-700 font-medium">
              Enter percentages (leave blank or 0 to exclude)
            </div>

            <div className="space-y-2">
              {memberOptions.map((m) => (
                <div key={m.id} className="flex items-center justify-between gap-3">
                  <div className="text-sm">
                    {m.name} <span className="text-gray-500">({m.email})</span>
                  </div>
                  <input
                    type="number"
                    value={splitDetails[m.id] ?? ""}
                    onChange={(e) => setSplitValue(m.id, e.target.value)}
                    className="w-32 rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-black"
                    placeholder="0.00"
                  />
                </div>
              ))}
            </div>

            <div className="text-xs text-gray-500">
              Total: {percentTotal.toFixed(2)}% / 100%
            </div>
          </div>
        ) : null}

        <div className="flex justify-end gap-2">
          <Button type="button" onClick={onClose} className="bg-gray-100">
            Cancel
          </Button>
          <Button disabled={loading} type="submit" className="bg-black text-white">
            {loading ? "Updating..." : "Update Expense"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
