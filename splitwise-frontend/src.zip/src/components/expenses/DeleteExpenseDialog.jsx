import Modal from "../common/Modal";
import Button from "../common/Button";

export default function DeleteExpenseDialog({ open, onClose, expense, onConfirm }) {
  return (
    <Modal open={open} title="Delete Expense" onClose={onClose}>
      <div className="space-y-4">
        <p className="text-gray-700">
          Are you sure you want to delete{" "}
          <span className="font-semibold">{expense?.description}</span>?
        </p>

        <div className="flex justify-end gap-2">
          <Button onClick={onClose} className="bg-gray-100">
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            className="bg-red-600 text-white"
          >
            Delete
          </Button>
        </div>
      </div>
    </Modal>
  );
}
