export default function Button({ children, className = "", ...props }) {
  return (
    <button
      {...props}
      className={`rounded-xl px-4 py-2 font-medium transition hover:opacity-90 disabled:opacity-50 ${className}`}
    >
      {children}
    </button>
  );
}
