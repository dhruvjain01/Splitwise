export default function Input({ label, ...props }) {
  return (
    <div className="flex flex-col gap-1">
      {label ? <label className="text-sm text-gray-600">{label}</label> : null}
      <input
        {...props}
        className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-black"
      />
    </div>
  );
}
