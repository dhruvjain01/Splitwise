import { useState } from "react";
import Modal from "../common/Modal";
import Input from "../common/Input";
import Button from "../common/Button";

export default function CreateGroupModal({ open, onClose, onCreate }) {
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr("");

    if (!name.trim()) {
      setErr("Group name is required");
      return;
    }

    try {
      setLoading(true);
      await onCreate({ name: name.trim() });
      setName("");
      onClose();
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to create group");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open={open} title="Create Group" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        {err ? <p className="text-sm text-red-600">{err}</p> : null}

        <Input
          label="Group Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Eg: Goa Trip"
        />

        <div className="flex gap-2 justify-end">
          <Button
            type="button"
            onClick={onClose}
            className="bg-gray-100"
          >
            Cancel
          </Button>
          <Button
            disabled={loading}
            type="submit"
            className="bg-black text-white"
          >
            {loading ? "Creating..." : "Create"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
