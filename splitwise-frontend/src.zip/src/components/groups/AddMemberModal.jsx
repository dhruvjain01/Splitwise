import { useState } from "react";
import Modal from "../common/Modal";
import Input from "../common/Input";
import Button from "../common/Button";

export default function AddMemberModal({ open, onClose, onAdd }) {
  const [email, setEmail] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr("");

    if (!email.trim()) {
      setErr("Email is required");
      return;
    }

    try {
      setLoading(true);
      await onAdd({ email: email.trim() }); // ✅ backend likely expects email
      setEmail("");
      onClose();
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to add member");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open={open} title="Add Member" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        {err ? <p className="text-sm text-red-600">{err}</p> : null}

        <Input
          label="Member email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter email to add"
        />

        <div className="flex gap-2 justify-end">
          <Button type="button" onClick={onClose} className="bg-gray-100">
            Cancel
          </Button>
          <Button disabled={loading} type="submit" className="bg-black text-white">
            {loading ? "Adding..." : "Add"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
