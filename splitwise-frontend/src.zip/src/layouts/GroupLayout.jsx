import { NavLink, Outlet, useParams } from "react-router-dom";

const tabClass = ({ isActive }) =>
  `px-4 py-2 rounded-xl text-sm font-medium transition ${
    isActive ? "bg-black text-white" : "bg-white border hover:bg-gray-50"
  }`;

export default function GroupLayout() {
  const { groupId } = useParams();

  return (
    <div className="max-w-5xl mx-auto space-y-4">
      <div className="flex flex-wrap gap-2">
        <NavLink to={`/groups/${groupId}`} end className={tabClass}>
          Dashboard
        </NavLink>
        <NavLink to={`/groups/${groupId}/expenses`} className={tabClass}>
          Expenses
        </NavLink>
        <NavLink to={`/groups/${groupId}/balances`} className={tabClass}>
          Balances
        </NavLink>
        <NavLink to={`/groups/${groupId}/settle`} className={tabClass}>
          Settle
        </NavLink>
      </div>

      <div className="rounded-2xl border bg-white p-4">
        <Outlet />
      </div>
    </div>
  );
}
