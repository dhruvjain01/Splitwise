import { useEffect, useState } from "react";
import Button from "../../components/common/Button";
import CreateGroupModal from "../../components/groups/CreateGroupModal";
import GroupCard from "../../components/groups/GroupCard";
import { groupService } from "../../services/groupService";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function GroupsListPage() {
  const nav = useNavigate();
  const { authReady, accessToken } = useAuth();

  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [open, setOpen] = useState(false);

  const loadGroups = async () => {
    try {
      setErr("");
      setLoading(true);
      const list = await groupService.getGroups();
      setGroups(list || []);
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to load groups");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Only call API AFTER auth bootstrap completed + token exists
  useEffect(() => {
    if (!authReady) return;
    if (!accessToken) return;
    loadGroups();
  }, [authReady, accessToken]);

  const createGroup = async (payload) => {
    await groupService.createGroup(payload);
    await loadGroups();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Groups</h1>
        <Button onClick={() => setOpen(true)} className="bg-black text-white">
          + Create Group
        </Button>
      </div>

      {loading ? <p>Loading groups...</p> : null}
      {err ? <p className="text-red-600 text-sm">{err}</p> : null}

      {!loading && groups.length === 0 ? (
        <div className="rounded-2xl border bg-white p-6 text-gray-600">
          No groups yet. Create your first group 🚀
        </div>
      ) : null}

      <div className="grid md:grid-cols-2 gap-4">
        {groups.map((g) => (
          <GroupCard
            key={g.id}
            group={g}
            onClick={() => nav(`/groups/${g.id}`)}
          />
        ))}
      </div>

      <CreateGroupModal
        open={open}
        onClose={() => setOpen(false)}
        onCreate={createGroup}
      />
    </div>
  );
}
