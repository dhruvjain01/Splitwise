import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Button from "../../components/common/Button";
import MembersList from "../../components/groups/MembersList";
import AddMemberModal from "../../components/groups/AddMemberModal";
import { groupService } from "../../services/groupService";

export default function GroupDashboardPage() {
  const { groupId } = useParams();

  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [openAdd, setOpenAdd] = useState(false);

  const loadMembers = async () => {
    try {
      setErr("");
      setLoading(true);
      const list = await groupService.getMembers(groupId);
      setMembers(list || []);
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to load members");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMembers();
  }, [groupId]);

  const addMember = async (payload) => {
    await groupService.addMember(groupId, payload);
    await loadMembers();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-xl font-bold">Group Dashboard</h1>
          <p className="text-sm text-gray-500">Group ID: {groupId}</p>
        </div>

        <Button onClick={() => setOpenAdd(true)} className="bg-black text-white">
          + Add Member
        </Button>
      </div>

      {err ? <p className="text-sm text-red-600">{err}</p> : null}
      {loading ? <p>Loading members...</p> : <MembersList members={members} />}

      <AddMemberModal
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        onAdd={addMember}
      />
    </div>
  );
}
