import { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { balanceService } from "../../services/balanceService";
import { groupService } from "../../services/groupService";
import { formatCurrency } from "../../utils/formatCurrency";

export default function BalancesPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [members, setMembers] = useState([]);
  const [oweLines, setOweLines] = useState([]); // [{fromUserId,toUserId,amount}]

  const userMap = useMemo(() => {
    const map = {};
    (members || []).forEach((m) => {
      const id = m.id || m.userId;
      map[id] = { name: m.name || m.email, email: m.email };
    });
    return map;
  }, [members]);

  const getName = (userId) => userMap[userId]?.name || userId;

  /**
   * ✅ Smart per-user summary based on PAIRWISE net
   * pairNet[userId][otherUserId] = signed amount
   *  +ve => user gets from other
   *  -ve => user owes other
   */
  const userCards = useMemo(() => {
    const users = (members || []).map((m) => m.id || m.userId);

    const pairNet = {};
    const net = {};

    users.forEach((u) => {
      pairNet[u] = {};
      net[u] = 0;
    });

    (oweLines || []).forEach((l) => {
      const from = l.fromUserId;
      const to = l.toUserId;
      const amt = Number(l.amount || 0);

      if (!from || !to || amt <= 0) return;

      // overall net
      net[from] = (net[from] || 0) - amt;
      net[to] = (net[to] || 0) + amt;

      // pairwise net
      pairNet[from][to] = (pairNet[from][to] || 0) - amt;
      pairNet[to][from] = (pairNet[to][from] || 0) + amt;
    });

    return users
      .map((userId) => {
        const userNet = Number(net[userId] || 0);

        let status = "settled";
        let total = 0;

        if (userNet > 0.01) {
          status = "gets";
          total = userNet;
        } else if (userNet < -0.01) {
          status = "owes";
          total = Math.abs(userNet);
        }

        const breakdown = Object.entries(pairNet[userId] || {})
          .map(([otherUserId, signedAmt]) => {
            const signed = Number(signedAmt || 0);
            const amount = Math.abs(signed);
            if (amount <= 0.01) return null;

            return {
              otherUserId,
              amount,
              type: signed > 0 ? "gets" : "owes",
            };
          })
          .filter(Boolean)
          .sort((a, b) => b.amount - a.amount);

        return {
          userId,
          name: getName(userId),
          email: userMap[userId]?.email,
          status,
          total,
          breakdown,
        };
      })
      .sort((a, b) => b.total - a.total);
  }, [members, oweLines, userMap]);

  const load = async () => {
    try {
      setErr("");
      setLoading(true);

      const membersList = await groupService.getMembers(groupId);
      setMembers(membersList || []);

      const lines = await balanceService.getBalances(groupId);
      setOweLines(lines || []);
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to load balances");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [groupId]);

  return (
    <div className="space-y-6">
      {/* ✅ Header + button */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Balances</h1>
          <p className="text-sm text-gray-500 mt-1">Group: {groupId}</p>
        </div>

        <button
          onClick={() => navigate(`/groups/${groupId}/settle`)}
          className="rounded-xl bg-black px-4 py-2 text-sm font-semibold text-white hover:bg-gray-900"
        >
          Settle Up
        </button>
      </div>

      {err ? <p className="text-sm text-red-600">{err}</p> : null}
      {loading ? <p>Loading balances...</p> : null}

      {!loading ? (
        <>
          {userCards.length === 0 ? (
            <div className="rounded-2xl border bg-gray-50 p-5 text-gray-600">
              No members found.
            </div>
          ) : (
            <div className="space-y-3">
              {userCards.map((c) => {
                const headerText =
                  c.status === "gets"
                    ? `${c.name} gets`
                    : c.status === "owes"
                    ? `${c.name} owes`
                    : `${c.name} is settled up`;

                const headerColor =
                  c.status === "gets"
                    ? "text-green-700"
                    : c.status === "owes"
                    ? "text-red-700"
                    : "text-gray-600";

                const badgeBg =
                  c.status === "gets"
                    ? "bg-green-50 border-green-200"
                    : c.status === "owes"
                    ? "bg-red-50 border-red-200"
                    : "bg-gray-50 border-gray-200";

                return (
                  <div
                    key={c.userId}
                    className="rounded-2xl border bg-white overflow-hidden"
                  >
                    {/* header */}
                    <div className="flex items-center justify-between p-4">
                      <div className="text-left">
                        <div className={`text-base font-semibold ${headerColor}`}>
                          {headerText}
                        </div>
                        {c.email ? (
                          <div className="text-xs text-gray-500 mt-1">{c.email}</div>
                        ) : null}
                      </div>

                      <div className={`rounded-xl border px-3 py-2 ${badgeBg}`}>
                        {c.status === "settled" ? (
                          <div className="text-sm font-semibold text-gray-600">Settled</div>
                        ) : (
                          <div className={`text-sm font-bold ${headerColor}`}>
                            {formatCurrency(c.total)}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* ✅ breakdown always visible */}
                    <div className="border-t bg-gray-50 p-4 space-y-2">
                      {c.status === "settled" ? (
                        <div className="text-sm text-gray-600">
                          🎉 No balances pending for {c.name}.
                        </div>
                      ) : c.breakdown.length === 0 ? (
                        <div className="text-sm text-gray-600">No breakdown available.</div>
                      ) : (
                        c.breakdown.map((it, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between rounded-xl border bg-white p-3"
                          >
                            <div className="text-sm">
                              {it.type === "gets" ? (
                                <>
                                  <span className="font-semibold">{c.name}</span>{" "}
                                  <span className="text-gray-600">gets back from</span>{" "}
                                  <span className="font-semibold">{getName(it.otherUserId)}</span>
                                </>
                              ) : (
                                <>
                                  <span className="font-semibold">{c.name}</span>{" "}
                                  <span className="text-gray-600">owes</span>{" "}
                                  <span className="font-semibold">{getName(it.otherUserId)}</span>
                                </>
                              )}
                            </div>

                            <div
                              className={`text-sm font-semibold ${
                                it.type === "gets" ? "text-green-700" : "text-red-700"
                              }`}
                            >
                              {formatCurrency(it.amount)}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      ) : null}
    </div>
  );
}
