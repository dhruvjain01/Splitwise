import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Button from "../../components/common/Button";
import ExpenseList from "../../components/expenses/ExpenseList";
import AddExpenseModal from "../../components/expenses/AddExpenseModal";
import EditExpenseModal from "../../components/expenses/EditExpenseModal";
import DeleteExpenseDialog from "../../components/expenses/DeleteExpenseDialog";
import { expenseService } from "../../services/expenseService";
import { groupService } from "../../services/groupService";

export default function ExpensesPage() {
  const { groupId } = useParams();

  const [members, setMembers] = useState([]);
  const [expenses, setExpenses] = useState([]);

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // add modal
  const [openAdd, setOpenAdd] = useState(false);

  // edit modal
  const [openEdit, setOpenEdit] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);

  // delete dialog
  const [openDelete, setOpenDelete] = useState(false);
  const [deletingExpense, setDeletingExpense] = useState(null);

  const loadAll = async () => {
    try {
      setErr("");
      setLoading(true);

      const [membersList, expenseList] = await Promise.all([
        groupService.getMembers(groupId),
        expenseService.getExpenses(groupId),
      ]);

      setMembers(membersList || []);
      setExpenses(expenseList || []);
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to load expenses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, [groupId]);

  const addExpense = async (payload) => {
    await expenseService.addExpense(groupId, payload);
    await loadAll();
  };

  const openEditModal = (expense) => {
    setEditingExpense(expense);
    setOpenEdit(true);
  };

  const updateExpense = async (payload) => {
    await expenseService.updateExpense(groupId, editingExpense.id, payload);
    await loadAll();
  };

  const openDeleteDialog = (expense) => {
    setDeletingExpense(expense);
    setOpenDelete(true);
  };

  const confirmDelete = async () => {
    await expenseService.deleteExpense(groupId, deletingExpense.id);
    setOpenDelete(false);
    setDeletingExpense(null);
    await loadAll();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-xl font-bold">Expenses</h1>
          <p className="text-sm text-gray-500">Group: {groupId}</p>
        </div>

        <Button onClick={() => setOpenAdd(true)} className="bg-black text-white">
          + Add Expense
        </Button>
      </div>

      {err ? <p className="text-sm text-red-600">{err}</p> : null}
      {loading ? (
        <p>Loading expenses...</p>
      ) : (
        <ExpenseList
          expenses={expenses}
          onEdit={openEditModal}
          onDelete={openDeleteDialog}
        />
      )}

      {/* Add */}
      <AddExpenseModal
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        members={members}
        onAdd={addExpense}
      />

      {/* Edit */}
      <EditExpenseModal
        open={openEdit}
        onClose={() => {
          setOpenEdit(false);
          setEditingExpense(null);
        }}
        members={members}
        expense={editingExpense}
        onUpdate={updateExpense}
      />

      {/* Delete */}
      <DeleteExpenseDialog
        open={openDelete}
        onClose={() => {
          setOpenDelete(false);
          setDeletingExpense(null);
        }}
        expense={deletingExpense}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
