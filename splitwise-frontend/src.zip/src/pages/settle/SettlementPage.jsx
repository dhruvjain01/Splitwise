import { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { settlementService } from "../../services/settlementService";
import { groupService } from "../../services/groupService";
import { balanceService } from "../../services/balanceService";
import { formatCurrency } from "../../utils/formatCurrency";

export default function SettlementPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [members, setMembers] = useState([]);
  const [settlements, setSettlements] = useState([]);

  // ✅ For reduction stats
  const [balancesLines, setBalancesLines] = useState([]);

  const userMap = useMemo(() => {
    const map = {};
    (members || []).forEach((m) => {
      const id = m.id || m.userId;
      map[id] = { name: m.name || m.email, email: m.email };
    });
    return map;
  }, [members]);

  const getName = (userId) => userMap[userId]?.name || userId;

  // ✅ Group by USER summary + list directly below
  const userCards = useMemo(() => {
    const users = (members || []).map((m) => m.id || m.userId);

    const incoming = {};
    const outgoing = {};
    const totalIn = {};
    const totalOut = {};

    users.forEach((u) => {
      incoming[u] = [];
      outgoing[u] = [];
      totalIn[u] = 0;
      totalOut[u] = 0;
    });

    (settlements || []).forEach((it) => {
      const from = it.fromUserId;
      const to = it.toUserId;
      const amt = Number(it.amount || 0);
      if (!from || !to || amt <= 0) return;

      outgoing[from].push({ otherUserId: to, amount: amt });
      totalOut[from] += amt;

      incoming[to].push({ otherUserId: from, amount: amt });
      totalIn[to] += amt;
    });

    return users
      .map((userId) => {
        const gets = Number(totalIn[userId] || 0);
        const owes = Number(totalOut[userId] || 0);

        let status = "settled";
        let total = 0;
        let list = [];

        if (gets > 0.01) {
          status = "gets";
          total = gets;
          list = incoming[userId].sort((a, b) => b.amount - a.amount);
        } else if (owes > 0.01) {
          status = "owes";
          total = owes;
          list = outgoing[userId].sort((a, b) => b.amount - a.amount);
        }

        return {
          userId,
          name: getName(userId),
          email: userMap[userId]?.email,
          status,
          total,
          list,
        };
      })
      .sort((a, b) => b.total - a.total);
  }, [settlements, members, userMap]);

  // ✅ reduction stats
  const reductionStats = useMemo(() => {
    const raw = balancesLines?.length || 0;
    const reduced = settlements?.length || 0;

    const reductionCount = Math.max(raw - reduced, 0);
    const reductionPct = (raw > 0 ? ((raw - reduced) / raw) * 100 : 0).toFixed(2);

    return { raw, reduced, reductionCount, reductionPct };
  }, [balancesLines, settlements]);

  const load = async () => {
    try {
      setErr("");
      setLoading(true);

      const membersList = await groupService.getMembers(groupId);
      setMembers(membersList || []);

      const list = await settlementService.getSettlement(groupId);
      setSettlements(list || []);

      // ✅ Also load balances count for comparison
      const lines = await balanceService.getBalances(groupId);
      setBalancesLines(lines || []);
    } catch (e) {
      setErr(e.response?.data?.message || "Failed to load settlement");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [groupId]);

  return (
    <div className="space-y-6">
      {/* ✅ Header + button */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Settle Up</h1>
          <p className="text-sm text-gray-500 mt-1">Group: {groupId}</p>
        </div>

        <button
          onClick={() => navigate(`/groups/${groupId}/balances`)}
          className="rounded-xl border px-4 py-2 text-sm font-semibold hover:bg-gray-50"
        >
          View Balances
        </button>
      </div>

      {err ? <p className="text-sm text-red-600">{err}</p> : null}
      {loading ? <p>Loading settlement...</p> : null}

      {!loading ? (
        <>
          <div className="rounded-2xl border bg-gray-50 p-4 text-sm text-gray-700">
            These are recommended payments to settle the group with minimum transactions.
          </div>

          {/* ✅ transaction reduction */}
          <div className="rounded-2xl border bg-white p-4">
            <div className="text-sm text-gray-500">Optimization</div>
            <div className="text-base font-semibold mt-1">
              Reduced transactions
            </div>

            <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-500">Raw balances</div>
                <div className="text-lg font-bold">{reductionStats.raw}</div>
              </div>

              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-500">Settlement transactions</div>
                <div className="text-lg font-bold">{reductionStats.reduced}</div>
              </div>

              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-500">Reduction</div>
                <div className="text-lg font-bold">
                  {reductionStats.reductionPct}% fewer
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Saved {reductionStats.reductionCount} transactions
                </div>
              </div>
            </div>
          </div>

          {userCards.length === 0 ? (
            <div className="rounded-2xl border bg-gray-50 p-5 text-gray-600">
              No members found.
            </div>
          ) : (
            <div className="space-y-3">
              {userCards.map((c) => {
                const headerText =
                  c.status === "gets"
                    ? `${c.name} gets`
                    : c.status === "owes"
                    ? `${c.name} owes`
                    : `${c.name} is settled up`;

                const headerColor =
                  c.status === "gets"
                    ? "text-green-700"
                    : c.status === "owes"
                    ? "text-red-700"
                    : "text-gray-600";

                const badgeBg =
                  c.status === "gets"
                    ? "bg-green-50 border-green-200"
                    : c.status === "owes"
                    ? "bg-red-50 border-red-200"
                    : "bg-gray-50 border-gray-200";

                return (
                  <div
                    key={c.userId}
                    className="rounded-2xl border bg-white overflow-hidden"
                  >
                    {/* header */}
                    <div className="flex items-center justify-between p-4">
                      <div className="text-left">
                        <div className={`text-base font-semibold ${headerColor}`}>
                          {headerText}
                        </div>
                        {c.email ? (
                          <div className="text-xs text-gray-500 mt-1">{c.email}</div>
                        ) : null}
                      </div>

                      <div className={`rounded-xl border px-3 py-2 ${badgeBg}`}>
                        {c.status === "settled" ? (
                          <div className="text-sm font-semibold text-gray-600">
                            Settled
                          </div>
                        ) : (
                          <div className={`text-sm font-bold ${headerColor}`}>
                            {formatCurrency(c.total)}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* list always visible */}
                    <div className="border-t bg-gray-50 p-4 space-y-2">
                      {c.status === "settled" ? (
                        <div className="text-sm text-gray-600">
                          🎉 No settlement needed for {c.name}.
                        </div>
                      ) : c.list.length === 0 ? (
                        <div className="text-sm text-gray-600">No breakdown available.</div>
                      ) : (
                        c.list.map((it, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between rounded-xl border bg-white p-3"
                          >
                            <div className="text-sm">
                              {c.status === "gets" ? (
                                <>
                                  <span className="font-semibold">{getName(it.otherUserId)}</span>{" "}
                                  <span className="text-gray-600">pays</span>{" "}
                                  <span className="font-semibold">{c.name}</span>
                                </>
                              ) : (
                                <>
                                  <span className="font-semibold">{c.name}</span>{" "}
                                  <span className="text-gray-600">pays</span>{" "}
                                  <span className="font-semibold">{getName(it.otherUserId)}</span>
                                </>
                              )}
                            </div>

                            <div
                              className={`text-sm font-semibold ${
                                c.status === "gets" ? "text-green-700" : "text-red-700"
                              }`}
                            >
                              {formatCurrency(it.amount)}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      ) : null}
    </div>
  );
}
